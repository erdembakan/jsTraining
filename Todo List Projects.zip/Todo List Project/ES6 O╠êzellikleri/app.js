// Spread Operator

// const langs = ["Phython", "Java","C++"];
// langs.push("C#");
// console.log(langs);



// Mapler Key (Anahtar) - Value(Değer)

// let MyMap = new Map();
// console.log(MyMap);

// const key1 = "Erdem";
// const key2 = {a:10, b:20};
// const key3 = () =>  2;

// MyMap.set(key1,"String");
// MyMap.set(key2,"Object Literal");
// MyMap.set(key3,"Arrow Function");

// // console.log(MyMap.get(key1));
// // console.log(MyMap.get(key2));
// // console.log(MyMap.get(key3));

// console.log(MyMap);


// Setler - Kümeler

const myset = new set();
//
myset.add(100);
myset.add("Erdem");
myset.add([1,2,3,4,5]);
myset.add(true);

console.log(myset.size);